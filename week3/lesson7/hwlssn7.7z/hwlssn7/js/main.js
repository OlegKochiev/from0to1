$(function () {
	$('.comments__list').slick({
		dots: true,
		prevArrow: false,
		nextArrow: false
	})

	$('.header__btn').on('click', function () {
		$('.header__container').toggleClass('header__container--active');
		$('.header__line1').toggleClass('header__line1--active');
		$('.header__line2').toggleClass('header__line2--active');
		$('.header__line3').toggleClass('header__line3--active');
	});
	var mixer = mixitup('.works__list');
})