$(function () {
	var mixer = mixitup('.works__content');
})