$(function () {
	var mixer = mixitup('.works__content');
	$('.comments__list').slick({
		dots: true,
		prevArrow: false,
		nextArrow: false
	})
})